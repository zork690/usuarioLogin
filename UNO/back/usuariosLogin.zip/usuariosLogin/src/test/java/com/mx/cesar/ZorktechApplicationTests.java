package com.mx.cesar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZorktechApplicationTests {

	@Test
	void contextLoads() {
	}

}
