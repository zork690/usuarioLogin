package com.mx.cesar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdeaLoginApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdeaLoginApplication.class, args);
	}

}
